
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class TextAnalyzer {
	public static void main(String[] args) throws FileNotFoundException {
		/** Reading file line by line */
		File file = new File("src/textFile.txt");
		Scanner scan = new Scanner(file);
		ArrayList<Word> wordsList= new ArrayList<>();
		System.out.println("Analyzing the text.......");
		
		while (scan.hasNextLine()) {
			String val = scan.nextLine(); // reading line by line
			val=val.replaceAll("[^a-zA-Z0-9]"," ");
			String[] wordsInLine=val.split(" ");
			//System.out.println(val);
			for(String word:wordsInLine) {
			if(wordsList.stream().anyMatch(o -> o.getWord().equals(word))) {
			for(Word w:wordsList) {
			if(w.getWord().equalsIgnoreCase(word)) {
			w.frequency++;
			//System.out.println(word);
			break;
			}
			}
			}else {
				wordsList.add(new Word(word,1));
			}
			//wordsList.add(new Word(word,1));
			//System.out.println(word);

			}
			
			
		}
		System.out.println("Sn	Word	:	frequency ");
		Collections.sort(wordsList);
		for (int i=1;i<=20;i++) {
			Word wordd=wordsList.get(i);
			System.out.println(i+""+wordd.toString());
		}
//// printing the list
		 //Collections.sort(wordsList);
		
	}
	

}
