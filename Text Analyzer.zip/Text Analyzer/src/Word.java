
public class Word implements Comparable {
	String word;
	int frequency;
	
	public Word() {
		super();
	}

	public Word(String word, int frequency) {
		super();
		this.word = word;
		this.frequency = frequency;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}


	@Override
	public String toString() {
		return "	"+ word + "	:	"+ frequency ;
	}

	@Override
	public int compareTo(Object o) {
	    int compar=((Word)o).getFrequency();
        /* For Ascending order*/
        return compar-this.frequency;

	}
	
	
}
